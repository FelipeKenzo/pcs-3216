#include "../include/Classifier.h"

Classifier::Classifier(std::vector<std::string>* src, std::string lstPath, std::vector<std::string> keywords, Recognizer* r, EventTreater* e) :
    src(src), keywords(keywords), r(r), e(e){
    
    lst.open(lstPath);
    if (!lst.is_open()) std::cerr << "could not open lst.\n";
}

void Classifier::readLine() {
    // std::cout << "nextLine read: " << e->nextLine << "\n"; 
    if (e->nextLine != lineNumber) {
        lineNumber = e->nextLine;
        if (lineNumber - 1 >= (*src).size()) { // End of file
            insertEvent(4);
            return;
        }
        currentLine = (*src)[lineNumber - 1];
        cindex = 0;

        // ignore empty lines
        while (currentLine == "") {
            if (lineNumber - 1 >= (*src).size()) { // End of file
                insertEvent(4);
                return;
            }
            lineNumber++;
            currentLine = (*src)[lineNumber - 1];
        }

        // std::cout << "Line (" << lineNumber << "): " << currentLine << "\n";
        insertEvent(2); // print line to listing
        insertEvent(1); // process the first char
    }
    else {
        insertEvent(0);
    }
}

void Classifier::processChar() {
    if (cindex >= currentLine.length()) {
        insertEvent(3); // finishes token
        return;
    }

    // ignore comments
    char c = currentLine[cindex++];

    // std::cout << "char: " << c << "\n";

    if (isAlphabetical(c)) {
        sequence += c;
        if (candidateType == integer) {
            candidateType = identifier;
        }
    }
    else if (isNumeric(c)) {
        if (sequence == "") {
            // std::cout << "oi\n";
            candidateType = integer;
            // std::cout << "Candidate type: " << candidateType << "\n";
        }
        sequence += c;
    }
    else {
        // std::cout << "Special Char\n";
        if (c != ' ') {
            // std::cout << "Not space\n";
            if (sequence == "") {
                // std::cout << "specialChar: " << c << "\n";
                sequence += c;
                candidateType = specialT;
            }
            else {
                // std::cout << "specialChar: " << c << "\n";
                // reprocess special char
                cindex--;
            }
        }
        
        // std::cout << sequence << "\n";
        // End of token
        insertEvent(3); // Sends token
        // std::cout << "Candidate type: " << candidateType << "\n";
        return;
    }

    insertEvent(1); // process next char
    // std::cout << "Candidate type: " << candidateType << "\n";
    return;
}

void Classifier::printLine() {
    lst << lineNumber << " " << currentLine << "\n";
    lst.flush();
    return;
}

void Classifier::sendToken() {

    // Checks if it is a keyword
    if (candidateType == identifier) {
        for (int i = 0; i < keywords.size() ; i++) {
            // std::cout << i << "\n";
            if (sequence == keywords[i]) {
                candidateType = keyword;
            }
        }
    }

    // std::cout << "oi\n";

    if (r->isRequestingToken()) {
        token t = {
            sequence,
            candidateType,
            lineNumber,
        };

        if (sequence != "") r->receiveToken(t);
        
        // Start processing next token
        if (cindex >= currentLine.length() || sequence == ";") {
            insertEvent(0);
        }
        else {
            insertEvent(1); 
        }
        sequence = "";
        candidateType = identifier;
    }
    else {
        insertEvent(3);
    }

}

void Classifier::waitDep() {
    if (sequence != "") {
        insertEvent(3);
        insertEvent(4);
    }
    else {
        eof = true;
    }
}

bool Classifier::isAlphabetical(char c) {
    return ((c >= 'A' && c <= 'Z') || (c >= 'a' && c <= 'z')
        || c == '.');
}

bool Classifier::isNumeric(char c) {
    return (c >= '0' && c <= '9');
}

// Abstract Methods

void Classifier::execute() {
    if (eventQueue.empty()) return;

    switch(eventQueue.front()) {
        case 0: readLine();
            break;
        case 1: processChar();
            break;
        case 2:
            printLine();
            break;
        case 3:
            sendToken();
            break;
        case 4:
            waitDep();
            break;
        default:
            break;
    }

    eventQueue.pop();
}