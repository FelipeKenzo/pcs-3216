#ifndef ENUMS_H
#define ENUMS_H

enum charType {
    special,
    alphabetic,
    numeric
};

enum tokenType {
    specialT,
    integer,
    identifier,
    keyword
};

#endif