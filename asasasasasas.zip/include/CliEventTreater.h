#ifndef CLIEVENTTREATER_H
#define CLIEVENTTREATER_H

#include <string>
#include <filesystem>
#include <fstream>

#include "EventTreater.h"
#include "Interface.h"
#include "VonNeumannMachine.h"
#include "Assembler.h"

class CliEventTreater : public EventTreater {
public:
    CliEventTreater();

protected:
    void executeTreatment();

    // =====================
    // == System Programs ==
    // =====================
    VonNeumannMachine* vnm;
    Assembler* a;
    void loadLoader();

    // ===================
    // == Job Variables ==
    // ===================
    std::string session = "";
    std::string disk = "";
    std::string diskfile = "";
    std::string inputPath = "";
    std::ifstream input;
    std::ofstream output;

    // ========================
    // == Treatment Routines ==
    // ========================

    void job();
    void setDisk();
    void directory();
    void create();
    void del();
    void list();
    void infile();
    void outfile();
    void setDiskfile();
    void run();
    void endjob();
};

#endif