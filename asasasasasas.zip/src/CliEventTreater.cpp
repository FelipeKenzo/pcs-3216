#include "../include/CliEventTreater.h"

CliEventTreater::CliEventTreater() {
}

void CliEventTreater::job() {
    if (session == "") {
        std::cout << "$JOB: starting job [" << t.sequence << "]\n";
        //std::cout << "1\n";
        session = t.sequence;
        //std::cout << "2\n";
        vnm = new VonNeumannMachine(&input, &output);
        //std::cout << "3\n";
        loadLoader();
    }
    else {
        std::cerr << "$JOB: Error: job [" << session << "] already runnning.\n";
    }
}

void CliEventTreater::setDisk() {
    if (session != "") {
        disk = t.sequence;
        std::cout << "$DISK: Disk set to [" << t.sequence << "]\n";
    }
    else {
        std::cerr << "$DISK: Error: no job is running.\n";
    }
}

void CliEventTreater::directory() {
    if (session != "") {
        std::string files = std::filesystem::current_path();
        files += "/" + disk;
        std::string fileName;
        std::cout << "\n$DIRECTORY: files in disk:\n";
        for (const auto & entry : std::filesystem::directory_iterator(files)) {
            fileName = entry.path();
            fileName = eraseSubStr(fileName, files + "/");
            std::cout << fileName << "\n";
        }
        std::cout << "\n";
    }
    else {
        std::cerr << "$DIRECTORY: Error: no job is running.\n";
    }
    return;
}

void CliEventTreater::create() {
    if (session != "") {
        std::string path = std::filesystem::current_path();
        path += "/" + disk + "/" + t.sequence;

        std::ofstream newFile;
        newFile.open(path);
        if (newFile.is_open()) {
            std::cout << "$CREATE: file [" << t.sequence << "] created.\n";
        }
        else {
            std::cout << "$CREATE: Error: file [" << t.sequence << "] could not be created.\n";
        }
        newFile.close();
    }
    else {
        std::cerr << "$CREATE: Error: no job is running.\n";
    }
}

void CliEventTreater::del() {
    if (session != "") {
        std::string path = "./" + disk + "/" + t.sequence;
        if (std::remove(path.c_str())) {
            std::cerr << "$DEL: Error: Cannot not remove [" << t.sequence << "] - no such file\n";
        }
        else {
            std::cout << "$DEL: File [" << t.sequence << "] deleted.\n";
        }
    }
    else {
        std::cerr << "$DEL: Error: no job is running.\n";
    }
}

void CliEventTreater::list() {
    if (session != "") {
        std::string path = disk + "/" + t.sequence;

        std::ifstream file;
        file.open(path);

        if (!file.is_open()) {
            std::cerr << "$LIST: Error: file [" << t.sequence << "] could not be opened.\n";
            return;
        }
        
        std::cout << "\n$LIST: listing contents of file [" << t.sequence << "]:\n";
        std::string line;
        while (std::getline(file, line)) {
            std::cout << line << "\n";
        }
        std::cout << "\n";
    }
    else {
        std::cerr << "$LIST: Error: no job is running.\n";
    }

}

void CliEventTreater::infile() {
    if (session != "") {
        std::string path = disk + "/" + t.sequence;
        inputPath = path;

        if (input.is_open()) {
            input.close();
        }
        
        input.open(path);

        if (input.is_open()) {
            std::cout << "$INFILE: file [" << t.sequence <<"] set as input.\n";
        }
        else {
            std::cerr << "$INFILE: Error: file [" << t.sequence << "] could not be opened.\n";
        }
    }
    else {
        std::cerr << "$INFILE: Error: no job is running.\n";
    }
}

void CliEventTreater::outfile() {
    if (session != "") {
        std::string path = disk + "/" + t.sequence;

        if (output.is_open()) {
            output.close();
        }
        
        output.open(path);

        if (output.is_open()) {
            std::cout << "$OUTFILE: file [" << t.sequence << "] set as output.\n";
        }
        else {
            std::cerr << "$OUTFILE: Error: file [" << t.sequence << "] could not be opened.\n";
        }
    }
    else {
        std::cerr << "$OUTFILE: Error: no job is running.\n";
    }
}

void CliEventTreater::setDiskfile() {
    if (session != "") {
        diskfile = disk + "/" + t.sequence;
        std::cout << "$DISKFILE: file [" << t.sequence << "] set as VNM disk.\n";
    }
    else {
        std::cerr << "$DISKFILE: Error: no job is running.\n";
    }
}

void CliEventTreater::run() {
    if (session != "") {
        // System programs
        if (t.sequence == "vnm") {
            std::cout << "$RUN vnm: initial PC? (0-4094): ";
            int addr;
            std::cin >> addr;

            vnm->setPC(addr);
            vnm->run();
        }
        else if (t.sequence == "assembler") {
            a = new Assembler(diskfile, diskfile, true);
            if (a->assemble()) {
                std::cout << "$RUN: assemble: success\n";
            }
        }
        else if (t.sequence == "loader") {
            if (input.is_open()) {
                input.close();
            }
            
            input.open(diskfile);
            vnm->setPC(0);
            vnm->run();

            input.close();

            if (inputPath != "") {
                input.open(inputPath);
            }
        }
    }
    else {
        std::cerr << "$RUN: Error: no job is running.\n";
    }
}

void CliEventTreater::endjob() {
    if (session != "") {
        session = "";
        delete(vnm);
        delete(a);
    }
    else {
        std::cerr << "$ENDJOB: Error: no job is running.\n";
    }
}

void CliEventTreater::executeTreatment() {
    nextLine = t.line + 1;
    switch(this->routine) {
        case 0: job();
            break;
        case  1: setDisk();
            break;
        case  2: directory();
            break;
        case  3: create();
            break;
        case  4: del();
            break;
        case  5: list();
            break;
        case  6: infile();
            break;
        case  7: outfile();
            break;
        case  8: setDiskfile();
            break;
        case  9: run();
            break;
        case 10: endjob();
            break;
    }
}

void CliEventTreater::loadLoader() {
    vnm->memWrite_w(0x00, 0x800B);
    vnm->memWrite_w(0x02, 0x500B);
    vnm->memWrite_w(0x04, 0x900B);
    vnm->memWrite_w(0x06, 0x000E);
    vnm->memWrite_w(0x08, 0x0001);
    vnm->memWrite_w(0x0A, 0x9000);
    vnm->memWrite_w(0x0C, 0x00FF);
    vnm->memWrite_w(0x0E, 0x800C);
    vnm->memWrite_w(0x10, 0x500C);
    vnm->memWrite_w(0x12, 0x900C);
    vnm->memWrite_w(0x14, 0xA05A);
    vnm->memWrite_w(0x16, 0x400A);
    vnm->memWrite_w(0x18, 0x902E);
    vnm->memWrite_w(0x1A, 0xA05A);
    vnm->memWrite_w(0x1C, 0x902F);
    vnm->memWrite_w(0x1E, 0x1022);
    vnm->memWrite_w(0x20, 0x0028);
    vnm->memWrite_w(0x22, 0x802E);
    vnm->memWrite_w(0x24, 0x500A);
    vnm->memWrite_w(0x26, 0x1058);
    vnm->memWrite_w(0x28, 0xA05A);
    vnm->memWrite_w(0x2A, 0x9008);
    vnm->memWrite_w(0x2C, 0xA05A);
    vnm->memWrite_w(0x2E, 0x9000);
    vnm->memWrite_w(0x30, 0x802F);
    vnm->memWrite_w(0x32, 0x4009);
    vnm->memWrite_w(0x34, 0x902F);
    vnm->memWrite_w(0x36, 0x1042);
    vnm->memWrite_w(0x38, 0x8008);
    vnm->memWrite_w(0x3A, 0x5009);
    vnm->memWrite_w(0x3C, 0x9008);
    vnm->memWrite_w(0x3E, 0x104A);
    vnm->memWrite_w(0x40, 0x002C);
    vnm->memWrite_w(0x42, 0x802E);
    vnm->memWrite_w(0x44, 0x4009);
    vnm->memWrite_w(0x46, 0x902E);
    vnm->memWrite_w(0x48, 0x0038);
    vnm->memWrite_w(0x4A, 0x800D);
    vnm->memWrite_w(0x4C, 0x500C);
    vnm->memWrite_w(0x4E, 0x900C);
    vnm->memWrite_w(0x50, 0xD000);
    vnm->memWrite_w(0x52, 0x500C);
    vnm->memWrite_w(0x54, 0x100E);
    vnm->memWrite_w(0x56, 0x900B);
    vnm->memWrite_w(0x58, 0xC00E);
    vnm->memWrite_w(0x5A, 0x0000);
    vnm->memWrite_w(0x5C, 0xD000);
    vnm->memWrite_w(0x5E, 0x9068);
    vnm->memWrite_w(0x60, 0x400C);
    vnm->memWrite_w(0x62, 0x900C);
    vnm->memWrite_w(0x64, 0x8068);
    vnm->memWrite_w(0x66, 0xB05A);
    
}